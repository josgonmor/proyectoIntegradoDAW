package net.josgonmor.ApiEventos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiEventosApplicationTests {

	@Test
	void contextLoads() {
	}

}
