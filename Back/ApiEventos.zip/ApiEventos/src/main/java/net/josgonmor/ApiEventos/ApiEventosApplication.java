package net.josgonmor.ApiEventos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiEventosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiEventosApplication.class, args);
	}

}
